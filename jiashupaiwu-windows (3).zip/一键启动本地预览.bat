@echo off
chcp 65001 >nul
title 全美房车加水排污与公路安全休息区 (最新全量雷达版)
echo ======================================================================
echo   全美 50 州公路安全休息区与房车加水排污全域雷达 (最新工作区同步版)
echo ======================================================================
echo.
echo [1] 正在为您检查本地浏览器环境...
echo.

where python >nul 2>nul
if %errorlevel% equ 0 (
    echo [OK] 检测到 Python，正在启动本地极速 HTTP 服务 (http://localhost:8080)...
    echo 浏览器将自动为您打开最新版本页面！按 Ctrl+C 可停止。
    start http://localhost:8080
    python -m http.server 8080
    goto end
)

where php >nul 2>nul
if %errorlevel% equ 0 (
    echo [OK] 检测到 PHP，正在启动本地服务 (http://localhost:8080)...
    start http://localhost:8080
    php -S 0.0.0.0:8080
    goto end
)

echo [提示] 未安装 Python/PHP，将直接为您在默认浏览器中打开 index.html...
echo (注意：由于现代浏览器安全策略，直接双击 html 访问本地 json 可能会受 CORS 限制，
echo  建议将解压后的文件夹放入 phpStudy / 宝塔 / IIS / Nginx 等本地网站目录即可完美运行！)
echo.
start index.html

:end
pause
